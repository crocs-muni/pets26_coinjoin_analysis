#!/bin/bash
# Starts the RPC server on 28183
python3 /jm/clientserver/scripts/jmwalletd.py > /home/joinmarket/jmwalletd.log 2>&1
